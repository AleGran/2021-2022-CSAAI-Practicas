 # Práctica 3
 El juego se inicia tras pulsar 'Espacio'. Para mover la pala usar las flechas del teclado de izquierda y derecha. En caso de querer pausar el juego, pulsar Escape. En caso de querer reiniciar la partida, pulsar la tecla 'r'. 
 El jugador tendrá 3 vidas. Tras perder una vida, la bola y la pala volverán a su posición inicial. Para volver a lanzar la bola, pulsar 'Espacio'. En caso de quedarse sin vidas la partida acabará. Para empezar una nueva simplemente pulsar 'Espacio'.
 La puntuación se mostrará arriba a la izquierda, valiendo cada bloque roto 1 punto.
