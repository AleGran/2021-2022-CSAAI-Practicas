 # Práctica 4
 
 Las modificaciones se aplicarán a la imagen mostrada a la izquierda. Dichas modificaciones serán mostradas en la imagen de la derecha.
 Para cambiar el color de la imagen, varíe los valores de los umbrales de cada color.
 Para aplicar un flitro gris, pulse el botón "Filtro Gris".
 Las mejoras incluídas son un filtro negativo y la posibilidad de reiniciar la aplicación.
 Para aplicar un filtro negativo, pulse el botón "Filtro Negativo".
 Para reiniciar la imagen y los valores de los umbrales de colores, pulse el botón "Resetear".
